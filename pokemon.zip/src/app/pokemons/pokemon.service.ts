import { Injectable } from "@angular/core";
import { POKEMONS } from "./mock-pokemons";
import { Pokemon } from "./pokemon";

@Injectable()
export class PokemonService{

    getPokemons(): Pokemon[] {
        return POKEMONS;
    }


    getPokemon(id: number) : Pokemon {
        let pokemons = this.getPokemons();
        return pokemons.find(x => x.id == id);
    }

    

    getPokemonTypes(): Array<string> {

        return [

            'Plante', 'Feu', 'Eau', 'Insecte', 'Normal', 'Electrik',

            'Poison', 'Fée', 'Vol', 'Combat', 'Psy'

        ]; 

    }
}