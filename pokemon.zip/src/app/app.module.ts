import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PageNotFoundComponent } from './page-not-found.component';
import { PokemonModule } from './pokemons/pokemon.module';

@NgModule({
  declarations: [
    AppComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule, //Demarrage de l'appli + Outils Angular (directives, interpolation, event..)
    PokemonModule,
    AppRoutingModule //Puis le routing
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
