import { Component, OnDestroy, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Subscription } from "rxjs";
//import { POKEMONS } from "./mock-pokemons"; //Maintenant gérer par le service
import { Pokemon } from "./pokemon";
import { PokemonService } from "./pokemon.service";

@Component({
    selector: 'detail-pokemon',
    templateUrl: './detail-pokemon.component.html'
})
export class DetailPokemonComponent implements OnInit, OnDestroy {
    constructor(private route: ActivatedRoute, private router: Router, private _pokemonService: PokemonService) {}

    public pokemons: Pokemon[];
    public pokemon: Pokemon;
    private routeSub : Subscription;

    ngOnInit() {
       // this.pokemons = POKEMONS;
        let id: number;
        
        this.routeSub = this.route.params.subscribe(params => {
            // Code
            id = params['id'];
          /*  for (let index = 0; index < this.pokemons.length; index++) {
                if (this.pokemons[index].id == id) {
                    this.pokemon = this.pokemons[index];
                }
            } */
            //Version TypeScript du FOR ci-dessus
            //this.pokemon = this.pokemons.find(x => x.id == id);
            //Ci-dessous retourne un array
            //this.pokemon = this.pokemons.filter(x => x.id == id)[0];
            this.pokemon = this._pokemonService.getPokemon(id);
        });
    }

    goBack(): void{
        this.router.navigate(['/pokemons']);
    }

    goEdit(pokemon: Pokemon) {
        let link =  ['/pokemon/edit', pokemon.id];
        this.router.navigate(link);
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}